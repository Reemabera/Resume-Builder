# Resume-Builder-Open.AI
I have created a resume builder AI that can create resumes for you. All you need to do is enter some information, such as your work experience and languages known. Our AI-powered system will then generate a customized resume for you.
